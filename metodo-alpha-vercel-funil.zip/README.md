# Método Alpha — projeto para Vercel

Landing page em Next.js, responsiva e pronta para publicar na Vercel. O checkout está separado do layout e usa uma rota de servidor (`/api/checkout`) com um adaptador neutro em `lib/payment.ts`.

## Rodar localmente

```bash
npm install
npm run dev
```

Abra http://localhost:3000.

## Publicar na Vercel

1. Envie esta pasta para um repositório GitHub.
2. Na Vercel, selecione **Add New → Project** e importe o repositório.
3. Framework: Next.js; Build Command: `npm run build`; Install Command: `npm install`.
4. Faça o deploy. Não precisa configurar gateway para publicar a página.

## Adicionar vídeo

Hospede seu vídeo MP4 em um serviço/CDN e configure `NEXT_PUBLIC_PROMO_VIDEO_URL` com a URL pública. O player aparece automaticamente. Não use link privado ou temporário.

## Integrar um gateway depois

1. Escolha o provedor e consulte a documentação oficial da API/SDK.
2. Na Vercel, abra **Settings → Environment Variables** e cadastre as credenciais privadas, por exemplo `PAYMENT_PROVIDER`, `PAYMENT_SECRET_KEY`, `PAYMENT_PUBLIC_KEY` e `PAYMENT_WEBHOOK_SECRET` (use somente as que o provedor exigir).
3. Implemente a criação da cobrança em `lib/payment.ts`, usando o SDK/API oficial do provedor, e retorne `checkoutUrl`.
4. Se o provedor exigir confirmação de pagamento, crie uma rota de webhook que valide assinatura e atualize o pedido no seu banco de dados.
5. Faça novo deploy para aplicar as variáveis.

**Importante:** o projeto não está conectado a nenhum gateway ainda. “Compatível com qualquer gateway” significa que a camada visual não depende de um fornecedor e pode receber um adaptador para o gateway escolhido; cada integração exige implementação específica. Nunca coloque chaves secretas em variáveis `NEXT_PUBLIC_` ou no código do navegador.

## Antes de vender

- Troque os depoimentos demonstrativos por avaliações reais e autorizadas, ou remova a seção.
- Revise a política de garantia/reembolso e publique somente condições que você realmente oferece.
- Atualize o e-mail de suporte no rodapé e inclua Termos de Uso e Política de Privacidade.
- Configure preço, identificação do produto, regras de entrega/acesso e fluxo de confirmação após pagamento.
- Use somente imagens, vídeos e textos que você tenha direito de publicar.
