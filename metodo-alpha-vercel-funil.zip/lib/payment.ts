export type CheckoutInput = {
  name: string;
  email: string;
  productId: string;
};

export type CheckoutResult = {
  checkoutUrl: string;
  provider: string;
};

/**
 * Adaptador neutro de pagamento.
 * Quando escolher o gateway, implemente a chamada oficial do provedor aqui.
 * Nunca coloque PAYMENT_SECRET_KEY em componentes/client-side.
 */
export async function createCheckout(_input: CheckoutInput): Promise<CheckoutResult> {
  const provider = process.env.PAYMENT_PROVIDER;
  if (!provider) {
    throw new Error('GATEWAY_NOT_CONFIGURED');
  }

  // Integração intencionalmente não implementada: cada adquirente/gateway
  // possui endpoint, autenticação, payload e regras próprios.
  // Adicione aqui o SDK/API oficial do provedor escolhido e retorne a URL real.
  throw new Error(`PROVIDER_ADAPTER_REQUIRED:${provider}`);
}
