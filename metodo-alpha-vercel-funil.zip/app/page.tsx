import Image from 'next/image';
import CheckoutButton from '@/components/CheckoutButton';
import ScrollEffects from '@/components/ScrollEffects';
import EntryFunnel from '@/components/EntryFunnel';

const videoUrl = process.env.NEXT_PUBLIC_PROMO_VIDEO_URL;

export default function Home() {
  return <main>
    <EntryFunnel />
    <ScrollEffects />
    <div className="scroll-progress" aria-hidden="true" />
    <header className="topbar"><a className="brand" href="#inicio"><span className="crown">♛</span><span><small>MÉTODO</small><strong>ALPHA</strong></span></a><nav><a href="#inicio">Início</a><a href="#beneficios">Benefícios</a><a href="#depoimentos">Depoimentos</a><a href="#garantia">Garantia</a></nav><a className="top-cta" href="#acesso">Acessar agora ↗</a></header>

    <section className="hero" id="inicio">
      <Image src="/hero-metodo-alpha.png" alt="Casal adulto em cena romântica com iluminação roxa" fill priority className="hero-image" sizes="100vw" />
      <div className="hero-shade" />
      <div className="hero-copy reveal reveal-left"><p className="eyebrow">DESENVOLVIMENTO • CONFIANÇA • CONEXÃO</p><h1>SEJA A SUA<br/>MELHOR VERSÃO<span>.</span></h1><p className="hero-lead">Desenvolva confiança, comunicação e habilidades para construir conexões mais verdadeiras.</p><CheckoutButton/><div className="trust-row"><span>◇ Conteúdo prático</span><span>✧ Acesso online</span><span>♧ Privacidade</span></div></div>
      <div className="video-card reveal reveal-right">{videoUrl ? <video controls playsInline poster="/hero-metodo-alpha.png"><source src={videoUrl} type="video/mp4"/>Seu navegador não suporta vídeo.</video> : <div className="video-placeholder"><span className="play">▶</span><strong>VÍDEO DE APRESENTAÇÃO</strong><small>Adicione seu vídeo em NEXT_PUBLIC_PROMO_VIDEO_URL</small></div>}</div>
    </section>

    <section className="learning section reveal-section" id="beneficios"><div className="learning-copy reveal reveal-left"><p className="eyebrow">UM CAMINHO DE EVOLUÇÃO</p><h2>O QUE VOCÊ VAI<br/><span>DESENVOLVER?</span></h2><p>Um conteúdo direto e aplicável para fortalecer sua postura, suas conversas e a maneira como você se relaciona com as pessoas.</p><ul className="check-list"><li>Comunicação clara e respeitosa</li><li>Autoconfiança e autoestima</li><li>Inteligência emocional</li><li>Como criar conexões saudáveis</li></ul></div><div className="feature-stack reveal reveal-right"><article><b>♡</b><span><strong>Mais confiança</strong><small>Expresse quem você é com autenticidade.</small></span></article><article><b>✧</b><span><strong>Comunicação melhor</strong><small>Ouça, converse e demonstre interesse.</small></span></article><article><b>⚡</b><span><strong>Atitude consciente</strong><small>Faça escolhas alinhadas aos seus valores.</small></span></article><article><b>♛</b><span><strong>Relações equilibradas</strong><small>Construa vínculos com respeito mútuo.</small></span></article></div></section>

    <section className="transform section reveal-section"><div className="transform-art reveal reveal-left"><div className="before"><span>ANTES</span><b>INSEGURANÇA</b></div><div className="after"><span>DEPOIS</span><b>CONFIANÇA</b></div></div><div className="transform-copy reveal reveal-right"><p className="eyebrow">SUA JORNADA COMEÇA AQUI</p><h2>MUDE SUA POSTURA.<br/><span>FORTALEÇA SUAS CONEXÕES.</span></h2><p>Não existe fórmula mágica para relacionamentos. Existe aprendizado, prática e respeito. O Método Alpha reúne ideias e exercícios para você evoluir no seu próprio ritmo.</p><div className="promise">✓ Conteúdo educativo, com foco em respeito e reciprocidade.</div></div></section>

    <section className="testimonials section reveal-section" id="depoimentos"><p className="eyebrow">EXPERIÊNCIAS DE APRENDIZADO</p><h2>RELATOS DE <span>ALUNOS</span></h2><p className="section-sub">Espaço reservado para avaliações verdadeiras de quem concluir o treinamento.</p><div className="quote-grid"><article><div className="stars">★★★★★</div><p>“O conteúdo me ajudou a refletir sobre minha comunicação e minhas atitudes.”</p><small>Depoimento demonstrativo — substitua por avaliação autorizada.</small></article><article><div className="stars">★★★★★</div><p>“Gostei da abordagem prática e dos exercícios para aplicar no dia a dia.”</p><small>Depoimento demonstrativo — substitua por avaliação autorizada.</small></article><article><div className="stars">★★★★★</div><p>“Passei a prestar mais atenção em escuta, respeito e confiança.”</p><small>Depoimento demonstrativo — substitua por avaliação autorizada.</small></article></div></section>

    <section className="guarantee section reveal-section" id="garantia"><div className="seal"><strong>7</strong><span>DIAS</span><small>GARANTIA</small></div><div><p className="eyebrow">COMPRA COM TRANQUILIDADE</p><h2>GARANTIA DE <span>7 DIAS</span></h2><p>Se houver uma política de reembolso de 7 dias aplicável à sua oferta, explique aqui as condições completas e o canal de atendimento. Confirme os termos antes de publicar.</p></div><div id="acesso"><CheckoutButton/><small className="secure-note">🔒 Ambiente preparado para checkout seguro</small></div></section>

    <footer className="reveal-section"><a className="brand" href="#inicio"><span className="crown">♛</span><span><small>MÉTODO</small><strong>ALPHA</strong></span></a><p>Conteúdo educativo sobre desenvolvimento pessoal e relacionamentos respeitosos.</p><div><a href="#beneficios">Conteúdo</a><a href="#garantia">Garantia</a><a href="mailto:suporte@seudominio.com">Suporte</a></div><small>© {new Date().getFullYear()} Método Alpha. Todos os direitos reservados.</small></footer>
    <a className="floating-cta" href="#acesso" aria-label="Ir para acesso ao treinamento">Quero acessar agora <span>↗</span></a>
  </main>;
}
