import { NextResponse } from 'next/server';
import { createCheckout } from '@/lib/payment';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    const email = typeof body.email === 'string' ? body.email.trim() : '';
    const productId = typeof body.productId === 'string' ? body.productId : 'metodo-alpha';

    if (name.length < 2 || !/^\S+@\S+\.\S+$/.test(email)) {
      return NextResponse.json({ error: 'Informe nome e e-mail válidos.' }, { status: 400 });
    }

    const checkout = await createCheckout({ name, email, productId });
    return NextResponse.json(checkout);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'UNKNOWN_ERROR';
    if (message === 'GATEWAY_NOT_CONFIGURED') {
      return NextResponse.json({ error: 'Pagamento ainda não configurado. Escolha um gateway para ativar o checkout.' }, { status: 503 });
    }
    if (message.startsWith('PROVIDER_ADAPTER_REQUIRED:')) {
      return NextResponse.json({ error: 'O provedor foi definido, mas falta implementar o adaptador de checkout.' }, { status: 501 });
    }
    return NextResponse.json({ error: 'Não foi possível iniciar o pagamento.' }, { status: 500 });
  }
}
