import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Método Alpha | Confiança, comunicação e relacionamentos',
  description: 'Um treinamento de desenvolvimento pessoal com foco em confiança, comunicação e relacionamentos saudáveis.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
