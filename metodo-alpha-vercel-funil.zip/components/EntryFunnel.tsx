'use client';

import { useMemo, useState } from 'react';

type Pain = 'confidence' | 'conversation' | 'rejection' | 'relationship' | 'social';
type Feeling = 'anxious' | 'stuck' | 'lonely' | 'ready';

const painOptions: { value: Pain; title: string; detail: string; icon: string }[] = [
  { value: 'confidence', title: 'Falta de confiança em mim', detail: 'Quero me sentir mais seguro e confortável sendo quem sou.', icon: '◇' },
  { value: 'conversation', title: 'Dificuldade para iniciar conversas', detail: 'Às vezes não sei o que dizer ou como demonstrar interesse.', icon: '✧' },
  { value: 'rejection', title: 'Medo de rejeição ou de me aproximar', detail: 'Acabo evitando situações por receio de não ser correspondido.', icon: '♡' },
  { value: 'relationship', title: 'Quero melhorar meus relacionamentos', detail: 'Quero me comunicar melhor e construir conexões saudáveis.', icon: '∞' },
  { value: 'social', title: 'Quero evoluir socialmente', detail: 'Quero me expressar melhor e me sentir à vontade em grupos.', icon: '⚡' },
];

const feelingOptions: { value: Feeling; title: string; detail: string }[] = [
  { value: 'anxious', title: 'Ansioso ou inseguro', detail: 'Penso demais antes de agir.' },
  { value: 'stuck', title: 'Travado', detail: 'Sei que quero mudar, mas não sei por onde começar.' },
  { value: 'lonely', title: 'Desanimado', detail: 'Sinto falta de conexões mais próximas.' },
  { value: 'ready', title: 'Pronto para praticar', detail: 'Quero um caminho e exercícios para começar.' },
];

const advice: Record<Pain, { title: string; text: string; steps: string[] }> = {
  confidence: { title: 'Comece fortalecendo a confiança, sem tentar ser outra pessoa.', text: 'Autoconfiança costuma crescer com pequenas experiências: reconhecer seus pontos fortes, respeitar seus limites e cumprir compromissos consigo mesmo.', steps: ['Escolha uma situação social simples para praticar esta semana.', 'Troque a cobrança por curiosidade: foque em aprender, não em impressionar.', 'Registre uma atitude sua da qual se orgulhou ao final do dia.'] },
  conversation: { title: 'Boas conversas começam com atenção genuína.', text: 'Você não precisa decorar frases prontas. Demonstrar interesse, escutar e fazer perguntas abertas costuma ser um começo mais natural.', steps: ['Abra com algo contextual e simples.', 'Faça uma pergunta aberta e escute a resposta.', 'Compartilhe algo seu também, mantendo a conversa equilibrada.'] },
  rejection: { title: 'O medo de rejeição pode diminuir com passos graduais.', text: 'Nem toda aproximação terá reciprocidade — e isso não define seu valor. Respeitar a resposta da outra pessoa e cuidar de si faz parte de relações saudáveis.', steps: ['Pratique interações de baixo risco, sem expectativa de resultado.', 'Observe sinais de interesse e respeite limites.', 'Depois de cada experiência, avalie o que aprendeu, não apenas o resultado.'] },
  relationship: { title: 'Relacionamentos melhores são construídos por duas pessoas.', text: 'Comunicação clara, escuta, respeito e reciprocidade são bases mais sólidas do que técnicas para controlar a reação de alguém.', steps: ['Expresse o que sente sem acusações.', 'Escute para compreender, não apenas para responder.', 'Converse sobre limites e expectativas com respeito.'] },
  social: { title: 'Sua desenvoltura social pode ser treinada aos poucos.', text: 'Familiaridade vem com prática. Em vez de tentar mudar tudo de uma vez, escolha situações pequenas e aumente o desafio gradualmente.', steps: ['Cumprimente alguém e sustente uma conversa breve.', 'Participe de uma atividade ligada a um interesse seu.', 'Pratique falar com clareza e também dar espaço aos outros.'] },
};

export default function EntryFunnel() {
  const [step, setStep] = useState(0);
  const [pain, setPain] = useState<Pain | null>(null);
  const [feeling, setFeeling] = useState<Feeling | null>(null);
  const result = useMemo(() => pain ? advice[pain] : null, [pain]);
  const feelingTip = feeling === 'anxious' ? 'Como você mencionou ansiedade, tente dividir a mudança em passos pequenos e gentis consigo mesmo.' : feeling === 'stuck' ? 'Como você se sente travado, escolha apenas uma ação simples para hoje; clareza também aparece enquanto praticamos.' : feeling === 'lonely' ? 'Se o desânimo estiver pesando, procure também estar perto de pessoas e atividades com as quais você se sinta acolhido.' : 'Como você está pronto para praticar, mantenha a constância e ajuste o ritmo conforme se sentir confortável.';

  function enterSite() {
    document.getElementById('inicio')?.scrollIntoView({ behavior: 'smooth' });
    document.body.classList.add('funnel-complete');
  }

  return (
    <section className="entry-funnel" aria-label="Descubra por onde começar">
      <div className="funnel-orb orb-one"/><div className="funnel-orb orb-two"/>
      <div className="funnel-shell">
        <div className="funnel-brand"><span>♛</span><div><small>MÉTODO</small><strong>ALPHA</strong></div></div>
        {step < 2 && <div className="funnel-progress"><span style={{ width: `${(step + 1) * 50}%` }} /></div>}
        {step === 0 && <div className="funnel-content" key="step-0">
          <p className="eyebrow">UM PRIMEIRO PASSO PARA SUA EVOLUÇÃO</p>
          <h1>O que mais está te <span>incomodando</span> neste momento?</h1>
          <p className="funnel-intro">Escolha a opção que mais combina com sua situação. Vamos compartilhar uma orientação inicial.</p>
          <div className="funnel-options">{painOptions.map(option => <button className={`funnel-option ${pain === option.value ? 'selected' : ''}`} key={option.value} onClick={() => setPain(option.value)}><b>{option.icon}</b><span><strong>{option.title}</strong><small>{option.detail}</small></span><i>{pain === option.value ? '✓' : '›'}</i></button>)}</div>
          <button className="funnel-primary" disabled={!pain} onClick={() => setStep(1)}>CONTINUAR <span>→</span></button>
          <button className="funnel-skip" onClick={enterSite}>Pular e conhecer o site</button>
        </div>}
        {step === 1 && <div className="funnel-content" key="step-1">
          <p className="eyebrow">SÓ MAIS UMA PERGUNTA</p>
          <h1>Como essa situação faz você <span>se sentir?</span></h1>
          <p className="funnel-intro">Não existe resposta certa. Isso ajuda a deixar a orientação mais relevante.</p>
          <div className="funnel-options">{feelingOptions.map(option => <button className={`funnel-option ${feeling === option.value ? 'selected' : ''}`} key={option.value} onClick={() => setFeeling(option.value)}><span><strong>{option.title}</strong><small>{option.detail}</small></span><i>{feeling === option.value ? '✓' : '›'}</i></button>)}</div>
          <div className="funnel-actions"><button className="funnel-back" onClick={() => setStep(0)}>← VOLTAR</button><button className="funnel-primary" disabled={!feeling} onClick={() => setStep(2)}>VER MINHA ORIENTAÇÃO <span>→</span></button></div>
          <button className="funnel-skip" onClick={enterSite}>Pular e conhecer o site</button>
        </div>}
        {step === 2 && result && <div className="funnel-content funnel-result" key="step-2">
          <p className="eyebrow">SUA ORIENTAÇÃO INICIAL</p>
          <div className="result-mark">✦</div>
          <h1>{result.title}</h1>
          <p className="funnel-intro">{result.text}</p>
          <p className="feeling-tip">{feelingTip}</p>
          <div className="result-steps"><strong>Três passos para começar:</strong>{result.steps.map((item, index) => <p key={item}><b>{String(index + 1).padStart(2, '0')}</b>{item}</p>)}</div>
          <p className="result-note">Essa é uma orientação educativa geral, não uma avaliação psicológica. Você pode avançar no seu próprio ritmo.</p>
          <button className="funnel-primary" onClick={enterSite}>CONHECER O MÉTODO ALPHA <span>→</span></button>
          <button className="funnel-skip" onClick={() => { setStep(0); setPain(null); setFeeling(null); }}>Refazer minhas respostas</button>
        </div>}
        <div className="funnel-privacy">🔒 Suas respostas ficam nesta página e não são enviadas nem armazenadas.</div>
      </div>
    </section>
  );
}
