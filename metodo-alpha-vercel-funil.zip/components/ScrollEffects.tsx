'use client';

import { useEffect } from 'react';

export default function ScrollEffects() {
  useEffect(() => {
    const targets = document.querySelectorAll<HTMLElement>('.reveal, .reveal-section, .quote-grid article, .feature-stack article');
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) {
      targets.forEach((el) => el.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.14, rootMargin: '0px 0px -45px 0px' });
    targets.forEach((el) => observer.observe(el));

    const updateScroll = () => {
      const doc = document.documentElement;
      const max = doc.scrollHeight - window.innerHeight;
      const progress = max > 0 ? (window.scrollY / max) * 100 : 0;
      doc.style.setProperty('--scroll-progress', `${progress}%`);
      document.body.classList.toggle('has-scrolled', window.scrollY > 420);
    };
    updateScroll();
    window.addEventListener('scroll', updateScroll, { passive: true });
    return () => {
      observer.disconnect();
      window.removeEventListener('scroll', updateScroll);
    };
  }, []);
  return null;
}
