'use client';

import { useState } from 'react';

export default function CheckoutButton() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage('Preparando checkout…');
    try {
      const response = await fetch('/api/checkout', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, productId: 'metodo-alpha' })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Não foi possível continuar.');
      if (data.checkoutUrl) window.location.assign(data.checkoutUrl);
      else setMessage('Checkout recebido, mas o gateway não retornou um link.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Erro ao iniciar pagamento.');
    } finally { setBusy(false); }
  }

  return <>
    <button className="btn btn-primary" onClick={() => { setOpen(true); setMessage(''); }}>Quero acessar agora <span>›</span></button>
    {open && <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) setOpen(false); }}>
      <section className="modal" role="dialog" aria-modal="true" aria-labelledby="checkout-title">
        <button className="modal-close" onClick={() => setOpen(false)} aria-label="Fechar">×</button>
        <p className="eyebrow">ACESSO AO TREINAMENTO</p><h2 id="checkout-title">Vamos começar?</h2>
        <p>Informe seus dados para continuar. O pagamento será ativado quando um gateway for integrado.</p>
        <form onSubmit={submit} className="checkout-form">
          <label>Seu nome<input required minLength={2} value={name} onChange={e => setName(e.target.value)} placeholder="Nome completo" /></label>
          <label>Seu e-mail<input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="voce@email.com" /></label>
          <button className="btn btn-primary full" disabled={busy}>{busy ? 'Aguarde…' : 'Continuar'}</button>
        </form>
        {message && <p className="form-message" role="status">{message}</p>}
        <small>Seus dados são usados apenas para dar continuidade ao pedido.</small>
      </section>
    </div>}
  </>;
}
