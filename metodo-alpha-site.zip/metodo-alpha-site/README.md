# Método Alpha — site de apresentação

## Como visualizar
Abra `index.html` no navegador. Para publicar, envie os três arquivos (`index.html`, `script.js` e este README, se desejar) para sua hospedagem.

## Personalizações obrigatórias antes de vender
1. Abra `script.js` e informe o link real do checkout em `CHECKOUT_URL`.
2. Informe o endereço do vídeo em `VIDEO_URL` (opcional).
3. Troque os textos e imagens de demonstração pelos materiais reais do seu produto.
4. Os depoimentos são exemplos de layout, não avaliações reais. Substitua por depoimentos verdadeiros, com autorização.
5. Revise política de privacidade, termos, garantia e informações da oferta. Não anuncie condições que você não oferece.

As imagens ilustrativas são carregadas de URLs externas do Unsplash e exigem internet para aparecer.
