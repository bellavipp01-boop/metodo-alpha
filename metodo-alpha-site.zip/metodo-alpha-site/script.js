// CONFIGURE ESTES LINKS ANTES DE PUBLICAR:
const CHECKOUT_URL = ""; // Ex.: https://seu-checkout.com/...
const VIDEO_URL = "";    // Ex.: https://www.youtube.com/watch?v=...

document.getElementById("year").textContent = new Date().getFullYear();

const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("navLinks");
menuBtn.addEventListener("click", () => nav.classList.toggle("show"));
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => nav.classList.remove("show")));

document.querySelectorAll(".faq-q").forEach(button => {
  button.addEventListener("click", () => {
    const item = button.closest(".faq-item");
    item.classList.toggle("open");
    button.querySelector("span").textContent = item.classList.contains("open") ? "−" : "+";
  });
});

const modal = document.getElementById("modal");
document.getElementById("videoBtn").addEventListener("click", () => {
  if (VIDEO_URL) window.open(VIDEO_URL, "_blank", "noopener,noreferrer");
  else modal.classList.add("show");
});
document.getElementById("closeModal").addEventListener("click", () => modal.classList.remove("show"));
modal.addEventListener("click", e => { if (e.target === modal) modal.classList.remove("show"); });
document.addEventListener("keydown", e => { if (e.key === "Escape") modal.classList.remove("show"); });

const checkout = document.getElementById("checkoutBtn");
document.querySelectorAll('a[href="#acessar"]').forEach(link => {
  link.addEventListener("click", () => {
    // Mantém o visitante na seção de compra.
  });
});
checkout.addEventListener("click", e => {
  if (!CHECKOUT_URL) {
    e.preventDefault();
    alert("Configure o link do seu checkout no arquivo script.js (variável CHECKOUT_URL) antes de publicar.");
    return;
  }
  checkout.href = CHECKOUT_URL;
  checkout.target = "_blank";
  checkout.rel = "noopener noreferrer";
});
